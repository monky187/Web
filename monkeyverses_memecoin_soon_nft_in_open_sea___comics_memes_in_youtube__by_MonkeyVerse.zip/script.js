document.addEventListener('DOMContentLoaded', () => {
  // Remove locked overlay from rewards card after a short delay
  setTimeout(() => {
    const rewardsCard = document.querySelector('.rewards-card');
    const lockedOverlay = rewardsCard.querySelector('.locked-overlay');
    if (lockedOverlay) {
      lockedOverlay.style.opacity = '0';
      setTimeout(() => {
        lockedOverlay.remove();
      }, 500);
    }
    rewardsCard.classList.remove('locked');
  }, 1000);

  // Add parallax effect to stars
  const stars = document.querySelector('.stars');
  if (stars) {
    document.addEventListener('mousemove', (e) => {
      const x = e.clientX / window.innerWidth;
      const y = e.clientY / window.innerHeight;
      stars.style.transform = `translate(${x * 20}px, ${y * 20}px)`;
    });
  }

  // Add subtle movement to collage images
  const collageImages = document.querySelectorAll('.collage-img');
  if (collageImages.length) {
    const handleMovement = (x, y) => {
      collageImages.forEach((img, index) => {
        const offset = (index + 1) * (window.innerWidth > 768 ? 10 : 5);
        img.style.transform = `
          rotate(${(index * 5) - 5}deg) 
          scale(1.1) 
          translate(${x * offset}px, ${y * offset}px)
        `;
      });
    };

    document.addEventListener('mousemove', (e) => {
      const x = e.clientX / window.innerWidth;
      const y = e.clientY / window.innerHeight;
      handleMovement(x, y);
    });

    document.addEventListener('touchmove', (e) => {
      const touch = e.touches[0];
      const x = touch.clientX / window.innerWidth;
      const y = touch.clientY / window.innerHeight;
      handleMovement(x, y);
    });
  }

  // Update NFT card hover effects and gallery transitions
  const nftCards = document.querySelectorAll('.nft-card');
  nftCards.forEach(card => {
    const monkey = card.querySelector('.monkey-avatar');
    if (monkey) {
      card.addEventListener('mouseover', () => {
        if (!monkey.classList.contains('cybermonkey')) {
          monkey.style.transform = 'scale(1.1)';
        }
      });
      
      card.addEventListener('mouseout', () => {
        if (!monkey.classList.contains('cybermonkey')) {
          monkey.style.transform = 'scale(1)';
        }
      });
    }

    // Handle gallery image transitions
    const images = card.querySelectorAll('.nft-gallery-img');
    if (images.length > 1) {
      let currentIndex = 0;
      images.forEach((img, index) => {
        if (index !== 0) img.style.opacity = '0';
      });
      
      setInterval(() => {
        images[currentIndex].style.opacity = '0';
        currentIndex = (currentIndex + 1) % images.length;
        images[currentIndex].style.opacity = '1';
      }, 3000);
    }
  });

  // Add pulsing effect to buttons
  const pulseButtons = ['.telegram-button', '.instagram-button'].map(selector => 
    document.querySelector(selector)
  ).filter(Boolean);

  pulseButtons.forEach(button => {
    setInterval(() => {
      button.style.transform = 'translateY(-3px)';
      setTimeout(() => {
        button.style.transform = 'translateY(0)';
      }, 500);
    }, 3000);
  });

  // Add hover effects for previews
  const previewElements = ['.telegram-preview', '.instagram-preview'].map(selector => 
    document.querySelector(selector)
  ).filter(Boolean);

  previewElements.forEach(element => {
    element.addEventListener('mouseover', () => {
      element.style.transform = 'scale(1.05)';
    });
    
    element.addEventListener('mouseout', () => {
      element.style.transform = 'scale(1)';
    });
  });

  // Add glow effect to lock icon
  const lockContainer = document.querySelector('.locked-container');
  const lockIcon = document.querySelector('.lock-icon');
  if (lockContainer && lockIcon) {
    lockContainer.addEventListener('mouseover', () => {
      lockIcon.style.filter = 'drop-shadow(0 0 10px #ff0000)';
    });
    
    lockContainer.addEventListener('mouseout', () => {
      lockIcon.style.filter = 'none';
    });
  }

  // Modified user system
  let users = JSON.parse(localStorage.getItem('users')) || [];
  let currentSession = JSON.parse(localStorage.getItem('currentSession'));
  let userOrderNumber = parseInt(localStorage.getItem('lastOrderNumber') || '0');

  function updateUserProfile() {
    const profilePic = document.getElementById('profilePicture');
    const username = document.getElementById('username');
    const tokenBalance = document.getElementById('totalRewards');
    
    if (currentSession) {
      if (profilePic) profilePic.src = currentSession.profileArt || '/1737077898553.png';
      if (username) username.textContent = currentSession.username;
      if (tokenBalance) tokenBalance.textContent = currentSession.tokens || 0;
    }
  }

  // Initialize art selection system with guest support
  function initializeArtSelection() {
    const artOptions = document.querySelectorAll('.art-option');
    
    artOptions.forEach(option => {
      option.addEventListener('click', () => {
        const artSrc = option.src;
        
        // Update profile picture immediately
        const slideshowContainer = document.getElementById('artSlideshow');
        if (slideshowContainer) {
          slideshowContainer.innerHTML = `<img src="${artSrc}" alt="Selected NFT Logo">`;
        }

        if (currentSession) {
          // Handle registered user
          currentSession.profileArt = artSrc;
          
          const userIndex = users.findIndex(u => u.email === currentSession.email);
          if (userIndex !== -1) {
            users[userIndex] = currentSession;
            localStorage.setItem('users', JSON.stringify(users));
            localStorage.setItem('currentSession', JSON.stringify(currentSession));
          }

          // Update username display
          const usernameElement = document.getElementById('username');
          if (usernameElement) {
            usernameElement.textContent = currentSession.username;
          }
        } else {
          // Handle guest user
          localStorage.setItem('guestProfileArt', artSrc);
          
          // Show guest message
          const usernameElement = document.getElementById('username');
          if (usernameElement) {
            usernameElement.textContent = 'Guest';
          }
        }

        // Update selected state for all options
        artOptions.forEach(opt => opt.classList.remove('selected'));
        option.classList.add('selected');
      });
    });

    // Set initial selected art and username
    const currentArt = currentSession?.profileArt || localStorage.getItem('guestProfileArt') || '/1737077898553.png';
    const selectedArtOption = Array.from(artOptions).find(opt => opt.src === currentArt);
    if (selectedArtOption) {
      selectedArtOption.classList.add('selected');
      
      // Update initial profile picture
      const slideshowContainer = document.getElementById('artSlideshow');
      if (slideshowContainer) {
        slideshowContainer.innerHTML = `<img src="${currentArt}" alt="Selected NFT Logo">`;
      }
    }
    
    // Set initial username
    const usernameElement = document.getElementById('username');
    if (usernameElement) {
      usernameElement.textContent = currentSession?.username || 'Guest';
    }
  }

  // Daily claim system with guest support
  function initializeClaimSystem() {
    const claimButton = document.querySelector('.claim-button');
    const claimTimer = document.querySelector('.claim-timer');
    
    if (!claimButton || !claimTimer) return;

    function updateClaimStatus() {
      const now = new Date();
      let lastClaimDate = null;
      
      if (currentSession) {
        lastClaimDate = currentSession.lastClaimDate ? new Date(currentSession.lastClaimDate) : null;
      } else {
        lastClaimDate = localStorage.getItem('guestLastClaim') ? new Date(localStorage.getItem('guestLastClaim')) : null;
      }
      
      if (!lastClaimDate || now - lastClaimDate >= 24 * 60 * 60 * 1000) {
        claimButton.textContent = 'CLAIM 100 MV';
        claimButton.disabled = false;
        claimTimer.textContent = 'Claim available!';
      } else {
        const timeLeft = 24 * 60 * 60 * 1000 - (now - lastClaimDate);
        const hours = Math.floor(timeLeft / (1000 * 60 * 60));
        const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
        claimButton.textContent = 'CLAIMED TODAY';
        claimButton.disabled = true;
        claimTimer.innerHTML = `Next claim in:<br>${hours}h ${minutes}m`;
      }
    }

    claimButton.addEventListener('click', () => {
      const now = new Date();
      
      if (currentSession) {
        // Handle registered user claim
        currentSession.tokens = (currentSession.tokens || 0) + 100;
        currentSession.lastClaimDate = now.toISOString();
        
        const userIndex = users.findIndex(u => u.email === currentSession.email);
        if (userIndex !== -1) {
          users[userIndex] = currentSession;
          localStorage.setItem('users', JSON.stringify(users));
          localStorage.setItem('currentSession', JSON.stringify(currentSession));
        }
        document.getElementById('totalRewards').textContent = currentSession.tokens;
      } else {
        // Handle guest claim
        const guestTokens = parseInt(localStorage.getItem('guestTokens') || '0');
        localStorage.setItem('guestTokens', guestTokens + 100);
        localStorage.setItem('guestLastClaim', now.toISOString());
        document.getElementById('totalRewards').textContent = guestTokens + 100;
      }

      // Show success animation
      const rewardPopup = document.createElement('div');
      rewardPopup.className = 'reward-popup';
      rewardPopup.textContent = '+100 MV';
      claimButton.parentElement.appendChild(rewardPopup);
      setTimeout(() => rewardPopup.remove(), 1000);

      updateClaimStatus();
    });

    // Initialize claim timer
    setInterval(updateClaimStatus, 60000);
    updateClaimStatus();

    // Initialize guest tokens display if needed
    if (!currentSession) {
      const guestTokens = localStorage.getItem('guestTokens');
      if (guestTokens) {
        document.getElementById('totalRewards').textContent = guestTokens;
      }
    }
  }

  // Profile editing system
  function initializeProfileEditing() {
    const editButton = document.getElementById('editUsername');
    const usernameElement = document.getElementById('username');

    if (!editButton || !usernameElement) return;

    editButton.addEventListener('click', () => {
      if (!currentSession) {
        alert('Please login to edit your profile!');
        return;
      }

      const newUsername = prompt('Enter new username:', currentSession.username);
      if (newUsername && newUsername.trim()) {
        currentSession.username = newUsername.trim();
        
        const userIndex = users.findIndex(u => u.email === currentSession.email);
        if (userIndex !== -1) {
          users[userIndex] = currentSession;
          localStorage.setItem('users', JSON.stringify(users));
          localStorage.setItem('currentSession', JSON.stringify(currentSession));
        }

        updateUserProfile();
      }
    });
  }

  // Initialize slideshow with guest support
  function loadSlideshow() {
    const slideshow = document.getElementById('artSlideshow');
    if (!slideshow) return;

    slideshow.innerHTML = '';
    const img = document.createElement('img');
    img.src = currentSession?.profileArt || localStorage.getItem('guestProfileArt') || '/1737077898553.png';
    slideshow.appendChild(img);
  }

  function rotateSlideshow() {
    const images = document.getElementById('artSlideshow').getElementsByTagName('img');
    images[0].style.opacity = '0';
    setTimeout(() => {
      images[0].remove();
      loadSlideshow();
    }, 1000);
  }

  // Initialize all new systems
  initializeClaimSystem();
  initializeArtSelection();
  initializeProfileEditing();

  // Update the registration system
  function registerUser(email, password, username) {
    if (users.find(u => u.email === email)) {
      alert('Email already registered!');
      return false;
    }

    userOrderNumber++;
    const initialArt = localStorage.getItem('guestProfileArt') || '/1737077898553.png';
    
    const newUser = {
      email,
      password,
      username,
      orderNumber: userOrderNumber,
      tokens: 0,
      profileArt: initialArt,
      lastClaimDate: null
    };

    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    localStorage.setItem('lastOrderNumber', userOrderNumber.toString());

    // Update profile display immediately after registration
    const slideshowContainer = document.getElementById('artSlideshow');
    if (slideshowContainer) {
      slideshowContainer.innerHTML = `<img src="${initialArt}" alt="Selected NFT Logo">`;
    }

    const usernameElement = document.getElementById('username');
    if (usernameElement) {
      usernameElement.textContent = username;
    }
    
    return newUser;
  }

  // Enhanced User Registration System with Order Numbers
  function updateUserDisplay() {
    const latestUser = users[users.length - 1];
    const userDisplay = document.getElementById('latestUserDisplay');
    if (latestUser && userDisplay) {
      userDisplay.innerHTML = `
        <div class="latest-user">
          <span class="user-number">#${latestUser.orderNumber}</span>
          <span class="user-name">${latestUser.username}</span>
          <button class="view-all-btn" onclick="toggleUserList()">
            <svg viewBox="0 0 24 24" class="arrow-icon">
              <path d="M7 10l5 5 5-5z"/>
            </svg>
          </button>
        </div>
      `;
    }
  }

  function toggleUserList() {
    const fullList = document.getElementById('userList');
    if (fullList) {
      fullList.classList.toggle('show-all');
    }
  }
  window.toggleUserList = toggleUserList; // Make function accessible globally

  function updateUserList() {
    const userList = document.getElementById('userList');
    if (!userList) {
      console.warn('User list element not found');
      return;
    }
    userList.innerHTML = '';
    users.forEach(user => {
      const div = document.createElement('div');
      div.className = 'user-item';
      div.textContent = user.username;
      userList.appendChild(div);
    });
  }

  // Modified login function to update profile display
  function login(email, password) {
    const user = users.find(u => u.email === email && u.password === password);
    if (user) {
      currentSession = user;
      localStorage.setItem('currentSession', JSON.stringify(user));
      
      // Update profile picture and username
      const slideshowContainer = document.getElementById('artSlideshow');
      if (slideshowContainer) {
        slideshowContainer.innerHTML = `<img src="${user.profileArt}" alt="Selected NFT Logo">`;
      }

      const usernameElement = document.getElementById('username');
      if (usernameElement) {
        usernameElement.textContent = user.username;
      }

      // Update token display
      const totalRewards = document.getElementById('totalRewards');
      if (totalRewards) {
        totalRewards.textContent = user.tokens || 0;
      }

      // Update UI elements
      const registerBtn = document.getElementById('registerBtn');
      const loginBtn = document.getElementById('loginBtn');
      const logoutBtn = document.getElementById('logoutBtn');
      
      if (registerBtn && loginBtn && logoutBtn) {
        registerBtn.style.display = 'none';
        loginBtn.style.display = 'none';
        logoutBtn.style.display = 'block';
      }

      return true;
    }
    return false;
  }

  function logout() {
    const currentUser = document.getElementById('currentUser');
    const totalRewards = document.getElementById('totalRewards');
    const registerBtn = document.getElementById('registerBtn');
    const loginBtn = document.getElementById('loginBtn');
    const logoutBtn = document.getElementById('logoutBtn');
    
    if (currentUser && totalRewards && registerBtn && loginBtn && logoutBtn) {
      currentSession = null;
      localStorage.removeItem('currentSession');
      currentUser.textContent = 'Guest';
      totalRewards.textContent = '0';
      registerBtn.style.display = 'block';
      loginBtn.style.display = 'block';
      logoutBtn.style.display = 'none';
    }
  }

  // Initialize registration elements and events
  const registerBtn = document.getElementById('registerBtn');
  const registerModal = document.getElementById('registerModal');
  const submitRegister = document.getElementById('submitRegister');
  const emailInput = document.getElementById('emailInput');
  const passwordInput = document.getElementById('passwordInput');
  const usernameInput = document.getElementById('usernameInput');

  let expectedCaptchaAnswer;

  if (registerBtn && registerModal) {
    registerBtn.addEventListener('click', () => {
      registerModal.style.display = 'block';
      expectedCaptchaAnswer = generateCaptcha();
    });
  }

  if (submitRegister && emailInput && passwordInput && usernameInput) {
    registerForm = document.getElementById('registerForm');
    registerForm.addEventListener('submit', (e) => {
      e.preventDefault();
      
      const email = emailInput.value.trim();
      const password = passwordInput.value.trim();
      const username = usernameInput.value.trim();
      const userAnswer = parseInt(document.getElementById('captchaAnswer').value);
      const emailConsent = document.getElementById('emailConsent').checked;

      if (userAnswer !== expectedCaptchaAnswer) {
        alert('Incorrect CAPTCHA answer. Please try again.');
        expectedCaptchaAnswer = generateCaptcha();
        document.getElementById('captchaAnswer').value = '';
        return;
      }

      const newUser = {
        email,
        password,
        username,
        emailConsent,
        tokens: 0,
        lastClaimDate: null,
        profileArt: '/1737077898553.png',
        orderNumber: ++userOrderNumber
      };

      users.push(newUser);
      localStorage.setItem('users', JSON.stringify(users));
      localStorage.setItem('lastOrderNumber', userOrderNumber.toString());

      login(email, password);
      registerModal.style.display = 'none';
      updateUserDisplay();
      alert('Registration successful! Welcome to MonkeyVerses!');
    });
  }

  window.onclick = (e) => {
    if (e.target === registerModal) {
      registerModal.style.display = 'none';
    }
  };

  function generateCaptcha() {
    const num1 = Math.floor(Math.random() * 10) + 1;
    const num2 = Math.floor(Math.random() * 10) + 1;
    const isAddition = Math.random() < 0.5;
    const operator = isAddition ? '+' : '-';
    const question = `${num1} ${operator} ${num2} = ?`;
    const answer = isAddition ? num1 + num2 : num1 - num2;
    
    document.getElementById('captchaQuestion').textContent = question;
    return answer;
  }

  // Initialize login/logout buttons
  const loginBtn = document.getElementById('loginBtn');
  const logoutBtn = document.getElementById('logoutBtn');

  if (loginBtn) {
    loginBtn.addEventListener('click', () => {
      const email = prompt('Enter email:');
      const password = prompt('Enter password:');
      if (!login(email, password)) {
        alert('Invalid credentials');
      }
    });
  }

  if (logoutBtn) {
    logoutBtn.addEventListener('click', logout);
  }

  // Initialize session
  const savedSession = JSON.parse(localStorage.getItem('currentSession'));
  if (savedSession) {
    currentSession = savedSession;
    login(savedSession.email, savedSession.password);
  }

  loadSlideshow();
  setInterval(rotateSlideshow, 1000);

  // Reward timer functionality
  const timerDisplay = document.getElementById('timerDisplay');
  const attemptsLeft = document.getElementById('attemptsLeft');
  
  // Timer functionality
  let countdown = 60;
  const claimButtonTimer = document.querySelector('.claim-button');
  const countdownDisplayTimer = document.querySelector('.countdown');

  function updateTimer() {
    const minutes = Math.floor(countdown / 60);
    const seconds = countdown % 60;
    timerDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    countdownDisplayTimer.textContent = `${countdown}s`;

    if (countdown === 0) {
      claimButtonTimer.disabled = false;
      countdown = 60;
    } else {
      countdown--;
    }
  }

  setInterval(updateTimer, 1000);

  // Update tap system
  const tapButton = document.querySelector('.claim-button');
  const tapCounter = document.getElementById('tapCounter');
  
  function updateTapDisplay() {
    if (currentSession && tapCounter) {
      tapCounter.textContent = `${currentSession.dailyTaps} taps left`;
      const totalRewards = document.getElementById('totalRewards');
      if (totalRewards) {
        totalRewards.textContent = currentSession.tokens || 0;
      }
    }
  }

  if (tapButton) {
    tapButton.addEventListener('click', () => {
      if (!currentSession) {
        alert('Please login first!');
        return;
      }

      const today = new Date().toDateString();
      if (currentSession.lastTapDate !== today) {
        currentSession.dailyTaps = 5000;
        currentSession.lastTapDate = today;
      }

      if (currentSession.dailyTaps > 0) {
        tapButton.classList.add('tapped');
        setTimeout(() => tapButton.classList.remove('tapped'), 100);

        const rewardsCard = document.querySelector('.rewards-card');
        if (rewardsCard) {
          const rewardPopup = document.createElement('div');
          rewardPopup.className = 'reward-popup';
          rewardPopup.textContent = '+1';
          rewardsCard.appendChild(rewardPopup);
          setTimeout(() => rewardPopup.remove(), 1000);
        }

        currentSession.dailyTaps--;
        currentSession.tokens = (currentSession.tokens || 0) + 1;
        
        const userIndex = users.findIndex(u => u.email === currentSession.email);
        if (userIndex !== -1) {
          users[userIndex] = currentSession;
          localStorage.setItem('users', JSON.stringify(users));
          localStorage.setItem('currentSession', JSON.stringify(currentSession));
        }

        updateTapDisplay();
      }
    });
  }

  // Initialize display
  if (users.length > 0) {
    updateUserDisplay();
    updateUserList();
  }

  // Simulated online users count
  function updateOnlineUsers() {
    const onlineCount = document.getElementById('onlineCount');
    if (onlineCount) {
      const baseUsers = 50;  // Base number of users
      const variation = Math.floor(Math.random() * 20) - 10;  // Random variation between -10 and +10
      const total = Math.max(baseUsers + variation, baseUsers - 10);  // Ensure we don't go below baseUsers - 10
      onlineCount.textContent = total;
    }
  }

  // Initial update
  updateOnlineUsers();

  // Update every 5 seconds
  setInterval(updateOnlineUsers, 5000);

  // Initialize modal close behavior
  if (registerModal) {
    registerModal.addEventListener('click', (e) => {
      if (e.target === registerModal) {
        registerModal.style.display = 'none';
      }
    });
  }

  // Modified timer to keep overlay visible
  const betaOverlays = document.querySelectorAll('.beta-overlay');
  
  // Remove animation to keep overlays visible
  betaOverlays.forEach(overlay => {
    overlay.style.animation = 'none';
  });
});